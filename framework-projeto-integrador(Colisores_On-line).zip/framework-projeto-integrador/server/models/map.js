import fs from 'fs/promises';
import sqlite3 from 'sqlite3';

/**
 * A classe Map no lado do servidor é responsável por carregar os dados do mapa
 * do Tiled (.json) e as informações de colisão de um banco de dados SQLite.
 * Ela gera uma matriz de colisão unificada para uso na lógica do jogo (ex: movimento de entidades).
 */
class Map {
    constructor() {
        this.map_data = null;
        this.tilewidth = 0;
        this.tileheight = 0;
        this.map_width = 0;
        this.map_height = 0;
        this.layers = [];
        this.matriz3D = []; // Matriz 3D com os GIDs de cada tile em cada camada
        this.col = {};      // Dicionário de colisão (tile_gid -> 1 se colide, 2 se não)
        this.collisionMatrix = []; // Matriz 2D final (0=livre, 1=bloqueado)
    }

    /**
     * Carrega os dados do mapa a partir de um arquivo JSON.
     * @param {string} filePath - Caminho para o arquivo .json do mapa.
     */
    async _loadMapData(filePath) {
        try {
            const data = await fs.readFile(filePath, 'utf8');
            this.map_data = JSON.parse(data);

            this.tilewidth = this.map_data.tilewidth;
            this.tileheight = this.map_data.tileheight;
            this.map_width = this.map_data.width;
            this.map_height = this.map_data.height;

            // Filtra apenas as camadas de tiles (tilelayer)
            const tileLayers = this.map_data.layers.filter(layer => layer.type === "tilelayer");
            
            // Cria a matriz 3D com os dados dos tiles
            this.matriz3D = tileLayers.map(layer => {
                // Converte o array 1D de dados em uma matriz 2D para facilitar o acesso
                const grid = [];
                for (let y = 0; y < this.map_height; y++) {
                    const row = layer.data.slice(y * this.map_width, (y + 1) * this.map_width);
                    grid.push(row);
                }
                return grid;
            });

        } catch (error) {
            console.error(`❌ Erro ao carregar o arquivo do mapa: ${error.message}`);
            throw error;
        }
    }

    /**
     * Carrega os dados de colisão do banco de dados SQLite.
     * @param {string} dbPath - Caminho para o arquivo .db do banco de dados.
     */
    async _loadCollisionData(dbPath) {
        return new Promise((resolve, reject) => {
            const db = new (sqlite3.verbose().Database)(dbPath, sqlite3.OPEN_READONLY, (err) => {
                if (err) {
                    console.error(`❌ Erro ao conectar ao banco de dados: ${err.message}`);
                    return reject(err);
                }
            });

            db.all("SELECT id, col FROM tile", [], (err, rows) => {
                if (err) {
                    console.error(`❌ Erro ao consultar a tabela 'tile': ${err.message}`);
                    db.close();
                    return reject(err);
                }
                
                // Popula o objeto de colisão: { tile_gid: 1 } para colisores
                this.col = rows.reduce((acc, row) => {
                    // Adiciona ao dicionário apenas os tiles que são colisores (col = 1)
                    if (row.col === 1) {
                        acc[row.id] = 1;
                    }
                    return acc;
                }, {});

                db.close();
                resolve();
            });
        });
    }

    /**
     * Gera a matriz de colisão 2D final.
     * Um tile é considerado bloqueado (1) se QUALQUER camada contiver um tile
     * que esteja no dicionário de colisão.
     */
    _generateCollisionMatrix() {
        const rows = this.map_height;
        const cols = this.map_width;
        // Inicializa a matriz com 0 (caminhável)
        this.collisionMatrix = Array(rows).fill(0).map(() => Array(cols).fill(0));

        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                // Itera sobre cada camada do mapa
                for (let l = 0; l < this.matriz3D.length; l++) {
                    const tile_gid = this.matriz3D[l][y][x];
                    
                    // Se o GID do tile estiver no nosso dicionário de colisores
                    if (this.col[tile_gid]) {
                        this.collisionMatrix[y][x] = 1; // Marca como bloqueado (1)
                        break; // Para a verificação, pois já sabemos que é um obstáculo
                    }
                }
            }
        }
    }
    
    /**
     * Verifica se uma determinada coordenada de TILE está bloqueada.
     * @param {number} tileX - A coordenada X do tile.
     * @param {number} tileY - A coordenada Y do tile.
     * @returns {boolean} Retorna true se o tile estiver bloqueado, false caso contrário.
     */
    isTileBlocked(tileX, tileY) {
        if (tileY >= 0 && tileY < this.map_height && tileX >= 0 && tileX < this.map_width) {
            return this.collisionMatrix[tileY][tileX] === 1;
        }
        return true; // Considera fora do mapa como bloqueado
    }


    /**
     * Factory function para criar e inicializar um objeto Map de forma assíncrona.
     * @param {string} mapPath - Caminho para o arquivo .json do mapa.
     * @param {string} dbPath - Caminho para o arquivo .db do banco de dados.
     * @returns {Promise<Map>} Uma promessa que resolve para uma instância de Mapa totalmente carregada.
     */
    static async create(mapPath, dbPath) {
        const map = new Map();
        await map._loadMapData(mapPath);
        await map._loadCollisionData(dbPath);
        map._generateCollisionMatrix(); // Gera a matriz de colisão após carregar os dados
        console.log("🗺️  Mapa e dados de colisão carregados no servidor.");
        return map;
    }
}

export default Map;