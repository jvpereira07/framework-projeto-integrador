/**
 * Processa o payload de input de um jogador, calcula o movimento e verifica a colisão.
 * @param {object} player - O objeto do jogador a ser atualizado.
 * @param {object} map - A referência ao mapa para verificações de colisão.
 * @param {object} gameState - O estado geral do jogo.
 */
export function handlePlayerInput(player, map, gameState) {
    if (!player.inputs) {
        player.moving = false;
        return;
    }

    const speed = player.stats.speed || 2;
    let dx = 0;
    let dy = 0;

    // --- 1. Calcular a Intenção de Movimento ---
    if (player.inputs.keys && (player.inputs.keys.up || player.inputs.keys.w)) dy -= 1;
    if (player.inputs.keys && (player.inputs.keys.down || player.inputs.keys.s)) dy += 1;
    if (player.inputs.keys && (player.inputs.keys.left || player.inputs.keys.a)) dx -= 1;
    if (player.inputs.keys && (player.inputs.keys.right || player.inputs.keys.d)) dx += 1;

    // --- 2. Atualizar Estado de Animação e Direção ---
    if (dx === 0 && dy === 0) {
        player.moving = false;
    } else {
        player.moving = true;
        // Atualiza a direção com base no último input dominante
        if (Math.abs(dx) > Math.abs(dy)) {
            player.direction = dx > 0 ? "right" : "left";
        } else {
            player.direction = dy > 0 ? "down" : "up";
        }
    }

    // Normalizar vetor para velocidade consistente na diagonal
    const magnitude = Math.sqrt(dx * dx + dy * dy);
    if (magnitude > 0) {
        dx = (dx / magnitude) * speed;
        dy = (dy / magnitude) * speed;
    }

    // --- 3. Lógica de Colisão e Movimento (A Correção Principal) ---
    // É crucial verificar os eixos X e Y separadamente.

    

    // Tenta mover no eixo X
    let newPosX = player.posx + dx;
    let nextTileX = Math.floor(newPosX / map.tilewidth);
    let currentTileY = Math.floor(player.posy / map.tileheight);
    
    if (!map.isTileBlocked(nextTileX, currentTileY)) {
        player.posx = newPosX;
    }

    // Tenta mover no eixo Y
    let newPosY = player.posy + dy;
    let nextTileY = Math.floor(newPosY / map.tileheight);
    let currentTileX = Math.floor(player.posx / map.tilewidth);

    console.log(`Tentando mover para tile (${nextTileX}, ${nextTileY}). Bloqueado?`, map.isTileBlocked(nextTileX, nextTileY));

    if (!map.isTileBlocked(currentTileX, nextTileY)) {
        player.posy = newPosY;
    }

    // --- 4. Lógica de Ataque ---
    if (player.inputs.mouse && player.inputs.mouse.button === 1) {
        player.atack(gameState, player.inputs.mouse);
    }

    // --- 5. Lógica da Interface (Inventário) ---
    if (player.inputs.keys && player.inputs.keys.inventory) {
        if (!player.inventoryKeyPressed) {
            player.ui_state = player.ui_state === 'hud' ? 'inventory' : 'hud';
            player.inventoryKeyPressed = true;
        }
    } else {
        player.inventoryKeyPressed = false;
    }
}